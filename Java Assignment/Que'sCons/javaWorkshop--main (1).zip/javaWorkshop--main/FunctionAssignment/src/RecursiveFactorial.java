
public class RecursiveFactorial {
	static int factorial(int n) {
		if (n == 0 || n == 1)
			return 1;

		return n * factorial(n - 1);
	}

	public static void main(String[] args) {
		java.util.Scanner sc = new java.util.Scanner(System.in);

		int n = sc.nextInt();

		System.out.println(factorial(n));

		sc.close();
	}
}
